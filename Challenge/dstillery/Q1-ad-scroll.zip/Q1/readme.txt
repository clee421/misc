How to run:
1. Unzip the file
2. cd into the folder
3. Execute index.html

The approach for this question was to keep everything as simple as possible.
The images are only loaded if the scroll is close
