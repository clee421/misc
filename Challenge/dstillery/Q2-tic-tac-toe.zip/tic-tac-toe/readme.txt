How to run:
1. Unzip the file
2. cd into the folder
3. Run `npm install` to get the dependencies
4. Run `npm start`

Comments
Using React/Redux is complete unnecesary for a simple tic tac toe game but this was a good example of how they work.
The approach for this game was to seperate each piece of the game so that refactoring does not affect other parts of the game.
Also with using react/redux the game will now scale well if a backend was implemented to handle score storage.
The board is also stored locally on every move so that a refresh of the board retains the board.
The logger is left in so that you can see how the actions interact with the reducers.