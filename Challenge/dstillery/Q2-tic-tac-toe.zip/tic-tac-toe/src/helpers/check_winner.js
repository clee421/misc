// This function will check for a winner and return
// the winner mark. It will return false if a winner
// hasn't been found. Null will be returns if nobody
// has won.
// "X" || "O" -> winner found
// false      -> no winner yet
// null       -> tied
export default (board) => {
  const rowWin = checkRows(board);
  if (rowWin) {
    return rowWin;
  }

  const colWin = checkCols(board);
  if (colWin) {
    return colWin;
  }

  const diagWin = checkDiags(board);
  if (diagWin) {
    return diagWin;
  }

  const tied = checkTie(board);
  if (tied) {
    return null;
  }

  return false;
};

const checkRows = board => {
  for( let r = 0; r < board.length; r++) {
    const row = board[r];

    // If the first element is null then theres no need to check further
    if (row[0] === null) continue;

    let count = 1;
    for(let i = 1; i < row.length; i++) {
      // If at any point there's no match then we stop checking
      // and we skip checking this row
      if(row[0] !== row[i]) break;

      // if we made it here then that means there was a match
      count++;
    }

    // If the counter matches the row's length then there's a full match
    if (count === row.length) return row[0];
  }

  return false;
};

const checkCols = board => {
  for( let c = 0; c < board.length; c++) {
    
    if (board[0][c] === null) continue;

    // The column check has similar logic as rows
    let count = 1;
    for( let j = 1; j < board.length; j++) {
      if(board[0][c] !== board[j][c]) break;
      count++;
    }

    // If the counter matches the columns's length then there's a full match
    if (count === board.length) return board[0][c];
  }

  return false;
};

const checkDiags = board => {
  const leftDiag = checkLeftDiagonal(board);
  if (leftDiag) {
    return leftDiag;
  }

  const rightDiag = checkRightDiagonal(board);
  if (rightDiag) {
    return rightDiag;
  }
  
  return false;
};

const checkLeftDiagonal = board => {
  // If the first mark is null then no need to keep checking
  if(board[0][0] === null) return false;
  
  for( let d = 1; d < board.length; d++) {
    // No match means we're done checking left diagonal
    if(board[0][0] !== board[d][d]) return false;
  }

  // Making it this far means they were all matches
  return board[0][0];
};

const checkRightDiagonal = board => {
  // If the first mark is null then no need to keep checking
  if(board[0][board.length - 1] === null) return false;

  for( let d = 1; d < board.length; d++) {
    // No match means we're done checking right diagonal
    if(board[0][board.length - 1] !== board[d][board.length - 1 - d]) return false;
  }

  return board[0][board.length - 1];
};

// Returns false if not tied, returns true if tied
const checkTie = board => {
  // Check through every mark on the board
  // If any of them are null then game isn't over yet
  for( let i = 0; i < board.length; i++) {
    for( let j = 0; j < board[i].length; j++) {
      if (board[i][j] === null) return false;
    }
  }

  return true;
};