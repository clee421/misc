export const MOVE_PIECE = 'MOVE_PIECE';
export const movePiece = (pos, mark) => ({
  type: MOVE_PIECE,
  pos,
  mark
});

export const SWITCH_PLAYER = 'SWITCH_PLAYER';
export const switchPlayer = () => ({
  type: SWITCH_PLAYER
});