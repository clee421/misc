export const RESET_BOARD = 'RESET_BOARD';
export const resetBoard = () => ({
  type: RESET_BOARD
});

export const RESET_PLAYER = 'RESET_PLAYER';
export const resetPlayer = () => ({
  type: RESET_PLAYER
});