import React from 'react';

///// CONTAINER /////
import { connect } from 'react-redux';
import { movePiece, switchPlayer } from 'actions/piece_actions';

class Piece extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      isHovered: false
    };

    this.handleClick = this.handleClick.bind(this);
    this.handleHover = this.handleHover.bind(this);
  }

  handleClick(pos, mark) {
    return (e) => {
      // On click we will move the piece and switch the player
      this.props.movePiece(pos, mark);
      this.props.switchPlayer();
      
      // Remove hover effect once player has picked the position
      this.setState({
        isHovered: false
      });
    };
  }

  handleHover(){
    this.setState({
        isHovered: !this.state.isHovered
    });
  }

  render() {
    const { piece, pos, mark } = this.props;

    // If the piece is null then assign the empty space
    let display = piece !== null ? piece : '\u00A0';

    // For hovering effect
    if (this.state.isHovered) {
      display = mark;
    }
    
    // Only if the space is empty can we put something there
    let click = null;
    let hover = null;
    if (piece === null) {
      click = this.handleClick(pos, mark);
      hover = this.handleHover;
    }

    return (
      <span 
        className='board-piece' 
        value={piece}
        onClick={click}
        onMouseEnter={hover}
        onMouseLeave={hover}
        >
        {display}
      </span>
    );
  }
}

///// CONTAINER /////
const mapStateToProps = ({ player }) => {
  return {
    mark: player.mark
  };
};

const mapDispatchToProps = dispatch => {
  return {
    movePiece: (pos, mark) => dispatch(movePiece(pos, mark)),
    switchPlayer: () => dispatch(switchPlayer())
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Piece);