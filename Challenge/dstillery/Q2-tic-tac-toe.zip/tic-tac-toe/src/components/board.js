import React from 'react';
import Piece from 'components/piece';

import 'css/board.css'; 

///// CONTAINER /////
import { connect } from 'react-redux';
import CheckWinner from 'helpers/check_winner';
import { resetBoard, resetPlayer } from 'actions/board_actions';

class Board extends React.Component {
  constructor(props) {
    super(props);

    this.handleClick = this.handleClick.bind(this);
  }

  handleClick() {
    this.props.resetBoard();
    this.props.resetPlayer();
  }

  render() {
    // Create the board display from the props
    const boardDisplay = [];
    this.props.board.forEach( (row, i) => {

      const rowDisplay = [];
      row.forEach( (piece, j) => {

        rowDisplay.push(
          <Piece key={`${i}${j}`} piece={piece} pos={[i, j]} />
        );
      });

      // This will create a row
      boardDisplay.push(
        <div key={i}>
          <span className='board-row'>
            {rowDisplay}
          </span>
        </div>
      );
    });

    let gameOver = null;
    if (this.props.winner) {
      gameOver = (
        <div className='victory'>
          <h2>{`Congrats ${this.props.winner} on the victory!`}</h2>
          <button onClick={this.handleClick}>play again?</button>
        </div>
      );
    }

    // If game is tied (a bit of duplicate code but looks cleaner this way)
    if (this.props.winner === null) {
      gameOver = (
        <div className='victory'>
          <h2>{`Tied game!`}</h2>
          <button onClick={this.handleClick}>play again?</button>
        </div>
      );
    }

    return (
      <section>
        <div className='board'>
          {boardDisplay}
        </div>
        {gameOver}
      </section>
    );
  }
}

///// CONTAINER /////
const mapStateToProps = ({ board }) => {
  return {
    board,
    winner: CheckWinner(board)
  };
};

const mapDispatchToProps = dispatch => {
  return {
    resetBoard: () => dispatch(resetBoard()),
    resetPlayer: () => dispatch(resetPlayer())
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Board);