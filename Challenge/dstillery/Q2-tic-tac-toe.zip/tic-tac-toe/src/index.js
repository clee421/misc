import React from 'react';
import ReactDOM from 'react-dom';
import Root from 'components/root';

import ConfigureStore from 'store/store';
import BoardState from 'store/default_state/board';
import registerServiceWorker from './registerServiceWorker';

document.addEventListener('DOMContentLoaded', () => {
  let store;
  const root = document.getElementById('root');

  // Check if we have a board
  try {
    const boardString = localStorage.getItem('ttt-board');
    
    let board = BoardState;
    if (boardString) {
      board = JSON.parse(boardString);
    }

    store = ConfigureStore({ board });
  }
  catch(err) {
    store = ConfigureStore();
  }

  ReactDOM.render(<Root store={store} />, root);
});
registerServiceWorker();
