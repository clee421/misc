export default {
  mark: "X"
};