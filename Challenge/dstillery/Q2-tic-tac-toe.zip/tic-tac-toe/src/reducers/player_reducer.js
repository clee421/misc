import merge from 'lodash/merge';
import InitialState from 'store/default_state/player';
import { SWITCH_PLAYER } from 'actions/piece_actions';
import { RESET_PLAYER } from 'actions/board_actions';

const playerReducer = (state = InitialState, action) => {
  Object.freeze(state);
  let currentState = merge({}, state);

  switch (action.type) {

    case SWITCH_PLAYER:
      if (currentState.mark === "X") {
        currentState.mark = "O";
        return currentState;
      }

      currentState.mark = "X";
      return currentState;

    case RESET_PLAYER:
      // Reset current player to initial state
      currentState = merge({}, InitialState);
      return currentState;

    default:
      return state;
  }
};

export default playerReducer;