import { combineReducers } from 'redux';
import boardReducer from 'reducers/board_reducer';
import playerReducer from 'reducers/player_reducer';

const rootReducer = combineReducers({
  board: boardReducer,
  player: playerReducer
});

export default rootReducer;