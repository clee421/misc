import merge from 'lodash/merge';
import InitialState from 'store/default_state/board';
import { MOVE_PIECE } from 'actions/piece_actions';
import { RESET_BOARD } from 'actions/board_actions';

const boardReducer = (state = InitialState, action) => {
  Object.freeze(state);
  let currentState = merge([], state);

  switch (action.type) {

    case MOVE_PIECE:
      let i = action.pos[0];
      let j = action.pos[1];
      currentState[i][j] = action.mark;
      
      // Store board state locally in case of refresh
      localStorage.setItem('ttt-board', JSON.stringify(currentState));

      return currentState;

    case RESET_BOARD:
      // Reset board to initial state
      currentState = merge([], InitialState);

      localStorage.setItem('ttt-board', JSON.stringify(currentState));

      return currentState;

    default:
      return state;
  }
};

export default boardReducer;